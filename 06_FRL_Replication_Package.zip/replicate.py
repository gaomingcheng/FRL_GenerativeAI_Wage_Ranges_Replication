from __future__ import annotations
from pathlib import Path
import argparse
from frl_analysis import run as run_frl
from frl_supplement import run as run_frl_supplement
from disclosure import run as run_disclosure
from frl_counterfactual import run as run_counterfactual
from frl_table_statistics import run as run_table_statistics
import gzip
import pickle
import math
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

PACKAGE_ROOT = Path(__file__).resolve().parent
ROOT = PACKAGE_ROOT / "replication_output"
(ROOT / "tables").mkdir(parents=True, exist_ok=True)
(ROOT / "figures").mkdir(parents=True, exist_ok=True)

with gzip.open(PACKAGE_ROOT / "replication_data.pkl.gz", "rb") as f:
    DATA = pickle.load(f)

START_QUARTER_N = 3
END_QUARTER_N = 11
BASE_QUARTER_N = 6
POST_START_QUARTER_N = 7
QUARTER_LABELS = {
    3: "2022Q3", 4: "2022Q4", 5: "2023Q1", 6: "2023Q2",
    7: "2023Q3", 8: "2023Q4", 9: "2024Q1",
    10: "2024Q2", 11: "2024Q3"
}

# Analysis-ready DataFrames are served directly from the consolidated data object.
_read_stata_original = pd.read_stata
_DATA_FILES = {
    "compact_liepin_posting.dta": "liepin_posting",
    "compact_listed_posting.dta": "listed_posting",
    "compact_liepin_firm.dta": "liepin_firm_quarter",
    "compact_listed_quarterly.dta": "listed_firm_quarter",
}
def _read_stata_from_package(path, columns=None, convert_categoricals=False, **kwargs):
    name = Path(path).name
    if name in _DATA_FILES:
        frame = DATA[_DATA_FILES[name]]
        return frame.loc[:, columns].copy() if columns is not None else frame.copy()
    return _read_stata_original(path, columns=columns, convert_categoricals=convert_categoricals, **kwargs)

pd.read_stata = _read_stata_from_package

def _check(label, value, target, tolerance):
    value = float(value)
    if not np.isfinite(value) or abs(value - float(target)) > float(tolerance):
        raise AssertionError(
            f"{label}: reproduced {value:.8f}; expected {float(target):.8f} "
            f"within tolerance {float(tolerance):.8f}"
        )

def _code(df, spec):
    if isinstance(spec, (tuple, list)):
        return pd.factorize(
            pd.MultiIndex.from_arrays([df[c] for c in spec]), sort=False
        )[0].astype(np.int32)
    return pd.factorize(df[spec], sort=False)[0].astype(np.int32)

def _drop_singletons(codes):
    keep = np.ones(len(codes[0]), dtype=bool)
    while True:
        idx = np.flatnonzero(keep)
        bad = np.zeros(len(keep), dtype=bool)
        for c in codes:
            cnt = np.bincount(c[idx], minlength=int(c.max()) + 1)
            bad[idx] |= cnt[c[idx]] <= 1
        nxt = keep & ~bad
        if nxt.sum() == keep.sum():
            return keep
        keep = nxt

def residualize(matrix, codes, iterations=20):
    r = np.asarray(matrix, dtype=np.float64).copy()
    if r.ndim == 1:
        r = r[:, None]
    for _ in range(iterations):
        for c in codes:
            cnt = np.bincount(c)
            nz = cnt > 0
            for j in range(r.shape[1]):
                sm = np.bincount(c, weights=r[:, j], minlength=len(cnt))
                mean = np.zeros_like(sm)
                mean[nz] = sm[nz] / cnt[nz]
                r[:, j] -= mean[c]
    return r

def prepare(df, ycols, xcols, fes, cluster, mask, extra_cols=()):
    req = list(dict.fromkeys(
        list(ycols) + list(xcols) + [cluster] +
        [c for fe in fes for c in (list(fe) if isinstance(fe, (tuple, list)) else [fe])] +
        list(extra_cols)
    ))
    m = mask.copy()
    m &= df[req].notna().all(axis=1)
    s = df.loc[m, req].reset_index(drop=True)
    codes = [_code(s, fe) for fe in fes]
    keep = _drop_singletons(codes)
    s = s.loc[keep].reset_index(drop=True)
    codes = [pd.factorize(c[keep], sort=False)[0].astype(np.int32) for c in codes]
    return s, codes

def _absorbed_df(codes, cluster):
    cl = pd.factorize(np.asarray(cluster), sort=False)[0].astype(np.int32)
    g = int(cl.max()) + 1
    out = 0
    for c in codes:
        ncat = int(c.max()) + 1
        mins = np.full(ncat, g, dtype=np.int32)
        maxs = np.full(ncat, -1, dtype=np.int32)
        np.minimum.at(mins, c, cl)
        np.maximum.at(maxs, c, cl)
        nested = bool(np.all(mins == maxs))
        if not nested:
            out += max(ncat - 1, 0)
    return out

def cluster_correction(codes, cluster, k):
    cl = pd.factorize(np.asarray(cluster), sort=False)[0].astype(np.int32)
    g = int(cl.max()) + 1
    n = len(cl)
    dfa = _absorbed_df(codes, cl)
    denom = max(n - k - dfa, 1)
    return (g / (g - 1)) * ((n - 1) / denom) if g > 1 else 1.0

def fit_hdfe(df, y, xs, fes, cluster, mask, iterations=20, extra_cols=()):
    s, codes = prepare(df, [y], xs, fes, cluster, mask, extra_cols)
    r = residualize(s[[y] + list(xs)].to_numpy(), codes, iterations)
    yy = r[:, 0]
    X = r[:, 1:]
    inv_xx = np.linalg.inv(X.T @ X)
    beta = inv_xx @ (X.T @ yy)
    resid = yy - X @ beta

    _, ci = np.unique(s[cluster].to_numpy(), return_inverse=True)
    g = int(ci.max()) + 1
    score = np.column_stack([
        np.bincount(ci, weights=X[:, j] * resid, minlength=g)
        for j in range(X.shape[1])
    ])
    meat = score.T @ score
    q = cluster_correction(codes, s[cluster].to_numpy(), len(xs))
    vcov = inv_xx @ meat @ inv_xx * q
    se = np.sqrt(np.diag(vcov))
    return {
        "beta": beta,
        "se": se,
        "N": len(s),
        "sample": s,
        "codes": codes,
        "residualized": r,
        "vcov": vcov,
    }

def one_reg_from_residualized(r, cluster, codes):
    y, x = r[:, 0], r[:, 1]
    xx = x @ x
    b = (x @ y) / xx
    e = y - b * x
    _, ci = np.unique(np.asarray(cluster), return_inverse=True)
    g = int(ci.max()) + 1
    score = np.bincount(ci, weights=x * e, minlength=g)
    q = cluster_correction(codes, cluster, 1)
    se = math.sqrt((score @ score) / (xx * xx) * q)
    return float(b), float(se)

def run_smoke_test():
    d = DATA["liepin_posting"]
    m = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
    fes = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
    r = fit_hdfe(d, "wage_spread", ["treatmentq_ie"], fes, "industry4n", m)
    _check("preferred coefficient", r["beta"][0], 0.0338386, 0.00020)
    _check("preferred clustered SE", r["se"][0], 0.0051212, 0.00020)
    _check("preferred sample size", r["N"], 1412458, 0.5)
    print(
        "SMOKE TEST PASSED | "
        f"beta={r['beta'][0]:.6f}, SE={r['se'][0]:.6f}, N={r['N']:,}"
    )

parser = argparse.ArgumentParser(description="Reproduce all results reported in the manuscript and online appendix.")
parser.add_argument("--smoke", action="store_true", help="Run only the preferred baseline numerical verification.")
parser.add_argument("--placebo-reps", type=int, default=None, help="Override the default 200 placebo permutations.")
parser.add_argument("--frl", action="store_true", help="Reproduce the revised manuscript tables and figure only.")
parser.add_argument("--frl-supplement", action="store_true", help=argparse.SUPPRESS)
parser.add_argument("--disclosure-input", type=Path, help="Run the disclosure analysis on a separately supplied unconditional CSV.")
parser.add_argument("--legacy", action="store_true", help="Run only the original supplementary specifications.")
parser.add_argument("--table-statistics", choices=["main","appendix","all"],
                    help="Reproduce the coefficient, inference and fit statistics for regression tables.")
args = parser.parse_args()
if args.table_statistics:
    segment = None if args.table_statistics == "all" else args.table_statistics
    run_table_statistics(DATA, fit_hdfe, prepare, residualize, cluster_correction,
                         one_reg_from_residualized, ROOT / "frl", segment)
    raise SystemExit(0)
if args.disclosure_input:
    run_disclosure(args.disclosure_input, fit_hdfe, ROOT / "disclosure")
    raise SystemExit(0)
if not (args.legacy or args.smoke) or args.frl or args.frl_supplement:
    if not args.frl_supplement:
        run_frl(DATA["liepin_posting"], fit_hdfe, ROOT / "frl")
    run_frl_supplement(DATA["liepin_posting"], DATA["listed_posting"], fit_hdfe, prepare, ROOT / "frl")
    if not args.frl_supplement:
        run_counterfactual(DATA["liepin_posting"], prepare, ROOT / "frl")
        run_table_statistics(DATA, fit_hdfe, prepare, residualize, cluster_correction,
                             one_reg_from_residualized, ROOT / "frl")
    if args.frl or args.frl_supplement:
        raise SystemExit(0)
if args.placebo_reps is not None:
    os.environ["FRL_PLACEBO_REPS"] = str(args.placebo_reps)
if args.smoke:
    run_smoke_test()
    raise SystemExit(0)


# ---- 00 summary statistics ----
def stats(s):
    return [len(s), s.mean(), s.std(), s.min(), s.max()]

d = pd.read_stata(ROOT / "data" / "compact_liepin_posting.dta", convert_categoricals=False)
m = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)

rows = []
for label, var in [
    ("Log average wage", "salary"),
    ("Log upper wage", "highest_salary"),
    ("Log lower wage", "lowest_salary"),
    ("Log wage spread", "wage_spread"),
    ("GenAI exposure", "exposure"),
]:
    vals = d.loc[m & d[var].notna(), var]
    rows.append([label] + stats(vals))
pd.DataFrame(rows, columns=["Variable", "N", "Mean", "SD", "Min", "Max"]).to_csv(
    ROOT / "tables" / "table_b1_summary.csv", index=False
)

fd = pd.read_stata(ROOT / "data" / "compact_liepin_firm.dta", convert_categoricals=False)
fm = fd["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
extra = ["routine_cognitive", "nonroutine_cognitive", "routine_physical", "nonroutine_physical"]
s, _ = prepare(
    fd, ["job_posting"], ["treatmentq_ie"], ["quarter_n", "id"],
    "industry4n", fm, extra_cols=extra
)
rows = []
for label, var in [
    ("Total postings (log)", "job_posting"),
    ("Routine cognitive postings", "routine_cognitive"),
    ("Non-routine cognitive postings", "nonroutine_cognitive"),
    ("Routine physical postings", "routine_physical"),
    ("Non-routine physical postings", "nonroutine_physical"),
]:
    rows.append([label] + stats(s[var]))
pd.DataFrame(rows, columns=["Variable", "N", "Mean", "SD", "Min", "Max"]).to_csv(
    ROOT / "tables" / "table_b2_summary.csv", index=False
)

qd = pd.read_stata(ROOT / "data" / "compact_listed_quarterly.dta", convert_categoricals=False)
qm = qd["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
rows = []
for label, var in [
    ("R&D intensity", "rd_int"),
    ("Invention patents (log)", "patent"),
    ("Labour productivity (log)", "labor"),
    ("Management efficiency (log)", "manage"),
    ("TFP (OP)", "TFP_OP"),
]:
    vals = qd.loc[qm & qd[var].notna(), var]
    rows.append([label] + stats(vals))
pd.DataFrame(rows, columns=["Variable", "N", "Mean", "SD", "Min", "Max"]).to_csv(
    ROOT / "tables" / "table_b3_summary.csv", index=False
)

# ---- 01 main results ----
p = ROOT / "data" / "compact_liepin_posting.dta"
cols = [
    "quarter_n", "wage_spread", "highest_salary", "lowest_salary", "treatmentq_ie",
    "id", "id_class2", "city_id", "industry4n", "part_time",
    "t2pre4", "t2pre3", "t2pre2", "t2current",
    "t2post1", "t2post2", "t2post3", "t2post4"
]
d = pd.read_stata(p, columns=cols, convert_categoricals=False)
m = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)

F1 = ["id", "id_class2", "quarter_n"]
F2 = ["id", "id_class2", ("city_id", "quarter_n")]
F3 = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]

rows = []
for label, fes in [
    ("Log range: occupation + firm + quarter", F1),
    ("Log range: + city x quarter", F2),
    ("Log range: + industry x quarter", F3),
]:
    r = fit_hdfe(d, "wage_spread", ["treatmentq_ie"], fes, "industry4n", m)
    rows.append([label, r["beta"][0], r["se"][0], r["N"]])

for y, label in [("highest_salary", "Log upper wage"), ("lowest_salary", "Log lower wage")]:
    r = fit_hdfe(d, y, ["treatmentq_ie"], F3, "industry4n", m)
    rows.append([label, r["beta"][0], r["se"][0], r["N"]])

pd.DataFrame(rows, columns=["Outcome / specification", "Coefficient", "SE", "N"]).to_csv(
    ROOT / "tables" / "table_c1_baseline.csv", index=False
)

xev = ["t2pre4", "t2pre3", "t2pre2", "t2current", "t2post1", "t2post2", "t2post3", "t2post4"]
labels = ["2022Q3", "2022Q4", "2023Q1", "2023Q3", "2023Q4", "2024Q1", "2024Q2", "2024Q3"]
r = fit_hdfe(d, "wage_spread", xev, F3, "industry4n", m)
ev = pd.DataFrame({"Quarter": labels, "Coefficient": r["beta"], "SE": r["se"]})
base = pd.DataFrame({"Quarter": ["2023Q2"], "Coefficient": [0.0], "SE": [0.0]})
ev = pd.concat([ev.iloc[:3], base, ev.iloc[3:]], ignore_index=True)
ev.to_csv(ROOT / "tables" / "table_event_study.csv", index=False)

x = np.arange(len(ev))
fig, ax = plt.subplots(figsize=(8, 5))
ax.errorbar(x, ev["Coefficient"], yerr=1.96 * ev["SE"], marker="o", capsize=3)
ax.axhline(0, linestyle="--")
ax.axvline(3.5, linestyle="--")
ax.set_xticks(x, ev["Quarter"], rotation=45, ha="right")
ax.set_xlabel("Quarter")
ax.set_ylabel("Coefficient on GenAI exposure")
ax.set_title("(a) Event-study estimates")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "fig1_event_study.png", dpi=220)
plt.close(fig)

# ---- 02 robustness ----
F3 = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
d = pd.read_stata(ROOT / "data" / "compact_liepin_posting.dta", convert_categoricals=False)
base = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)

rows = []
for label, x in [
    ("Median-split exposure", "treatment_high"),
    ("GPT-4 exposure (2023)", "exposure_gpt_dwa"),
    ("Claude-4 exposure (2023)", "exposure_claude_dwa"),
    ("GPT-4 exposure (future)", "exposure_gpt_future"),
    ("Claude-4 exposure (future)", "exposure_claude_fu"),
]:
    r = fit_hdfe(d, "wage_spread", [x], F3, "industry4n", base)
    rows.append([label, r["beta"][0], r["se"][0], r["N"]])
pd.DataFrame(rows, columns=["Specification", "Coefficient", "SE", "N"]).to_csv(
    ROOT / "tables" / "table_r2_alt_treatment.csv", index=False
)

r = fit_hdfe(
    d, "wage_spread", ["treatmentq_ie"], F3, "industry4n", base,
    extra_cols=["industry_1n", "industry_2n", "industry_3n"]
)
rows = []
for label, cl in [
    ("1-digit industry", "industry_1n"),
    ("2-digit industry", "industry_2n"),
    ("3-digit industry", "industry_3n"),
    ("Occupation class", "id_class2"),
    ("Firm", "id"),
]:
    b, se = one_reg_from_residualized(r["residualized"], r["sample"][cl], r["codes"])
    rows.append([label, b, se, r["N"]])
pd.DataFrame(rows, columns=["Cluster level", "Coefficient", "SE", "N"]).to_csv(
    ROOT / "tables" / "table_r3_clustering.csv", index=False
)

rows = []
for var, label in [
    ("traditional_ai_exposure", "Traditional-AI exposure x quarter"),
    ("covid_exposure", "Pandemic exposure x quarter"),
]:
    tmp = d.copy()
    xs = ["treatmentq_ie"]
    for q in range(START_QUARTER_N, END_QUARTER_N + 1):
        c = f"__{var}_q{q}"
        tmp[c] = np.where(tmp["quarter_n"].eq(q), tmp[var], 0.0)
        xs.append(c)
    rr = fit_hdfe(tmp, "wage_spread", xs, F3, "industry4n", base)
    rows.append([label, rr["beta"][0], rr["se"][0], rr["N"]])

ng = d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N) & (
    d["part_time"].isna() | d["gig_work"].isna()
)
rr = fit_hdfe(d, "wage_spread", ["treatmentq_ie"], F3, "industry4n", ng)
rows.append(["Non-gig sample", rr["beta"][0], rr["se"][0], rr["N"]])

m23 = d["part_time"].isna() & d["quarter_n"].between(5, END_QUARTER_N)
rr = fit_hdfe(d, "wage_spread", ["treatmentq_ie"], F3, "industry4n", m23)
rows.append(["2023+ sample", rr["beta"][0], rr["se"][0], rr["N"]])

pd.DataFrame(rows, columns=["Specification", "Coefficient", "SE", "N"]).to_csv(
    ROOT / "tables" / "table_r4_confounders.csv", index=False
)

ld = pd.read_stata(ROOT / "data" / "compact_listed_posting.dta", convert_categoricals=False)
lm = (ld["full_time"] == 1) & ld["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
rr = fit_hdfe(ld, "wage_spread", ["treatmentq_ie"], F3, "industry4n", lm)
pd.DataFrame(
    [["Listed firms", rr["beta"][0], rr["se"][0], rr["N"]]],
    columns=["Specification", "Coefficient", "SE", "N"]
).to_csv(ROOT / "tables" / "table_r1_listed_sample.csv", index=False)

s, codes = prepare(
    d, ["wage_spread"], ["treatmentq_ie", "treatment_aioe2"],
    F3, "industry4n", base
)
R = residualize(
    s[["wage_spread", "treatmentq_ie", "treatment_aioe2"]].to_numpy(),
    codes, 20
)
y, x, z = R.T
_, ci = np.unique(s["industry4n"], return_inverse=True)
g = int(ci.max()) + 1
q1 = cluster_correction(codes, s["industry4n"], 1)

def one_x_ols(a, b):
    xx = b @ b
    coef = (b @ a) / xx
    e = a - coef * b
    score = np.bincount(ci, weights=b * e, minlength=g)
    se = math.sqrt((score @ score) / (xx * xx) * q1)
    return coef, se

fs = one_x_ols(x, z)
rf = one_x_ols(y, z)
biv = (z @ y) / (z @ x)
e = y - biv * x
score = np.bincount(ci, weights=z * e, minlength=g)
seiv = math.sqrt((score @ score) / (z @ x) ** 2 * q1)
kp = (fs[0] / fs[1]) ** 2

s2, codes2 = prepare(
    d, ["wage_spread"], ["treatmentq_ie", "treatment_aioe2", "treatmentq_gpt"],
    F3, "industry4n", base
)
R2 = residualize(
    s2[["wage_spread", "treatmentq_ie", "treatment_aioe2", "treatmentq_gpt"]].to_numpy(),
    codes2, 20
)
y2, x2, z2, w2 = R2.T
ww = w2 @ w2
def partial(v):
    return v - w2 * (w2 @ v / ww)
y2, x2, z2 = map(partial, [y2, x2, z2])
b2 = (z2 @ y2) / (z2 @ x2)
e2 = y2 - b2 * x2
_, ci2 = np.unique(s2["industry4n"], return_inverse=True)
g2 = int(ci2.max()) + 1
score2 = np.bincount(ci2, weights=z2 * e2, minlength=g2)
q2 = cluster_correction(codes2, s2["industry4n"], 2)
se2 = math.sqrt((score2 @ score2) / (z2 @ x2) ** 2 * q2)

pd.DataFrame([
    ["First stage: US exposure x post", fs[0], fs[1], kp],
    ["Reduced form", rf[0], rf[1], np.nan],
    ["2SLS: exposure x post", biv, seiv, kp],
    ["2SLS + GPT control", b2, se2, np.nan],
], columns=["Stage / specification", "Coefficient", "SE", "KP F"]).to_csv(
    ROOT / "tables" / "table_r5_iv.csv", index=False
)

# ---- 03 mechanism ----
fd = pd.read_stata(ROOT / "data" / "compact_liepin_firm.dta", convert_categoricals=False)
m = fd["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
rows = []
for label, y in [
    ("Total postings", "job_posting"),
    ("Routine cognitive", "log_routine_cog_postings"),
    ("Non-routine cognitive", "log_nonroutine_cog_postings"),
    ("Routine physical", "log_routine_phys_postings"),
    ("Non-routine physical", "log_nonroutine_phys_postings"),
]:
    r = fit_hdfe(fd, y, ["treatmentq_ie"], ["quarter_n", "id"], "industry4n", m)
    rows.append([label, r["beta"][0], r["se"][0], r["N"]])
pd.DataFrame(rows, columns=["Outcome", "Coefficient", "SE", "N"]).to_csv(
    ROOT / "tables" / "table_m1_displacement.csv", index=False
)

qd = pd.read_stata(ROOT / "data" / "compact_listed_quarterly.dta", convert_categoricals=False)
m = qd["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
rows = []
for label, y in [
    ("TFP (OP)", "TFP_OP"),
    ("Management efficiency", "manage"),
    ("Labour productivity", "labor"),
    ("R&D intensity", "rd_int"),
    ("Patents", "patent"),
]:
    r = fit_hdfe(qd, y, ["treatmentq_ie"], ["id", "quarter_n"], "industry4n", m)
    rows.append([label, r["beta"][0], r["se"][0], r["N"]])
pd.DataFrame(rows, columns=["Outcome", "Coefficient", "SE", "N"]).to_csv(
    ROOT / "tables" / "table_m2_productivity.csv", index=False
)

# ---- 04 heterogeneity ----
d = pd.read_stata(ROOT / "data" / "compact_liepin_posting.dta", convert_categoricals=False)
base = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
F3 = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]

def table(specs, name):
    rows = []
    for label, mask in specs:
        r = fit_hdfe(d, "wage_spread", ["treatmentq_ie"], F3, "industry4n", mask)
        rows.append([label, r["beta"][0], r["se"][0], r["N"]])
    pd.DataFrame(rows, columns=["Subsample", "Coefficient", "SE", "N"]).to_csv(
        ROOT / "tables" / name, index=False
    )

table([
    ("Routine cognitive", base & d["routine_cognitive"].eq(1)),
    ("Non-routine cognitive", base & d["nonroutine_cognitive"].eq(1)),
    ("Routine physical", base & d["routine_physical"].eq(1)),
    ("Non-routine physical", base & d["nonroutine_physical"].eq(1)),
], "table_h1_occupation.csv")

table(
    [(str(k), base & d["total_skills4"].eq(k)) for k in [0, 1, 2]] +
    [("3+", base & d["total_skills4"].ge(3))],
    "table_h2_softskills.csv"
)
table([
    ("Tier 1", base & d["city_rank"].eq(1)),
    ("Non-tier 1", base & d["city_rank"].eq(0)),
], "table_h3_city.csv")
table([
    ("Master/PhD", base & d["masters_phd"].eq(1)),
    ("Below master", base & d["masters_phd"].eq(0)),
], "table_h4_education.csv")
table([
    ("<=5 years", base & d["exp_5_below"].eq(1)),
    ("5-10 years", base & d["exp_5_10"].eq(1)),
    (">10 years", base & d["exp_10_above"].eq(1)),
], "table_h5_experience.csv")

# ---- 05 placebo ----
cols = ["quarter_n", "wage_spread", "treatmentq_ie", "id", "id_class2", "city_id", "industry4n", "part_time"]
d = pd.read_stata(ROOT / "data" / "compact_liepin_posting.dta", columns=cols, convert_categoricals=False)
m = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
F3 = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
s, codes = prepare(d, ["wage_spread"], ["treatmentq_ie"], F3, "industry4n", m)

yr = residualize(s["wage_spread"].to_numpy(), codes, 25)[:, 0]
x = s["treatmentq_ie"].to_numpy(float)
xr = residualize(x, codes, 25)[:, 0]
main = float((xr @ yr) / (xr @ xr))

reps = int(os.environ.get("FRL_PLACEBO_REPS", "200"))
rng = np.random.default_rng(123)
betas = []
for _ in range(reps):
    xp = rng.permutation(x)
    xpr = residualize(xp, codes, 12)[:, 0]
    betas.append(float((xpr @ yr) / (xpr @ xpr)))

pd.DataFrame({"beta": betas}).to_csv(ROOT / "tables" / "placebo_coefficients.csv", index=False)
fig, ax = plt.subplots(figsize=(7, 5))
ax.hist(betas, bins=28)
ax.axvline(0, linestyle=":")
ax.axvline(main, linestyle="--")
ax.set_xlabel("Placebo coefficient")
ax.set_ylabel("Frequency")
ax.set_title("Permutation placebo test")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "fig2_placebo.png", dpi=220)
plt.close(fig)

# ---- 06 counterfactual ----
cols = [
    "quarter_n", "wage_spread", "treatmentq_ie", "exposure", "post2",
    "id", "id_class2", "city_id", "industry4n", "part_time"
]
d = pd.read_stata(
    ROOT / "data" / "compact_liepin_posting.dta",
    columns=cols, convert_categoricals=False
)
m = d["part_time"].isna() & d["quarter_n"].between(START_QUARTER_N, END_QUARTER_N)
F3 = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
r = fit_hdfe(
    d, "wage_spread", ["treatmentq_ie"], F3, "industry4n", m,
    extra_cols=["exposure", "post2"]
)
beta = float(r["beta"][0])
s = r["sample"].copy()
s["counterfactual"] = s["wage_spread"] - beta * s["treatmentq_ie"]

q = s.groupby("quarter_n")[["wage_spread", "counterfactual"]].mean().reset_index()
q["Quarter"] = q["quarter_n"].map(QUARTER_LABELS)
q.to_csv(ROOT / "tables" / "aggregate_counterfactual.csv", index=False)

post = q[q["quarter_n"] >= 7]
assert post["counterfactual"].mean() < post["wage_spread"].mean()
assert q["quarter_n"].min() == 3 and q["quarter_n"].max() == 11

fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(q["Quarter"], q["wage_spread"], marker="o", label="Observed")
ax.plot(q["Quarter"], q["counterfactual"], marker="o", linestyle="--", label="Counterfactual")
ax.axvline(3.5, linestyle="--")
ax.set_xlabel("Quarter")
ax.set_ylabel("Average log wage range")
ax.set_title("(b) Aggregate counterfactual")
ax.tick_params(axis="x", rotation=45)
ax.legend()
fig.tight_layout()
fig.savefig(ROOT / "figures" / "fig3_counterfactual.png", dpi=220)
plt.close(fig)

# ---- 07 build submission figure ----
a = Image.open(ROOT / "figures" / "fig1_event_study.png").convert("RGB")
b = Image.open(ROOT / "figures" / "fig3_counterfactual.png").convert("RGB")
canvas = Image.new("RGB", (a.width + b.width, max(a.height, b.height)), "white")
canvas.paste(a, (0, 0))
canvas.paste(b, (a.width, 0))
canvas.save(ROOT / "figures" / "Figure1_main_submission.png", quality=95)

# Numerical checks against the manuscript-level benchmarks.
_base = pd.read_csv(ROOT / "tables" / "table_c1_baseline.csv")
_pref = _base.loc[_base["Outcome / specification"].eq("Log range: + industry x quarter")].iloc[0]
_upper = _base.loc[_base["Outcome / specification"].eq("Log upper wage")].iloc[0]
_lower = _base.loc[_base["Outcome / specification"].eq("Log lower wage")].iloc[0]
_check("preferred coefficient", _pref["Coefficient"], 0.0338386, 0.00020)
_check("preferred clustered SE", _pref["SE"], 0.0051212, 0.00020)
_check("preferred sample size", _pref["N"], 1412458, 0.5)
_check("upper-wage coefficient", _upper["Coefficient"], -0.0518859, 0.00030)
_check("upper-wage SE", _upper["SE"], 0.0114639, 0.00030)
_check("lower-wage coefficient", _lower["Coefficient"], -0.0857245, 0.00030)
_check("lower-wage SE", _lower["SE"], 0.0117106, 0.00030)

_iv = pd.read_csv(ROOT / "tables" / "table_r5_iv.csv")
_ivrow = _iv.loc[_iv["Stage / specification"].eq("2SLS: exposure x post")].iloc[0]
_check("IV coefficient", _ivrow["Coefficient"], 0.0757956, 0.00060)
_check("IV standard error", _ivrow["SE"], 0.0123357, 0.00050)
_check("Kleibergen-Paap F", _ivrow["KP F"], 508.544, 2.0)

_m1 = pd.read_csv(ROOT / "tables" / "table_m1_displacement.csv").iloc[0]
_m2 = pd.read_csv(ROOT / "tables" / "table_m2_productivity.csv").iloc[0]
_check("total-posting coefficient", _m1["Coefficient"], -0.1323501, 0.00050)
_check("total-posting SE", _m1["SE"], 0.0897028, 0.00050)
_check("TFP coefficient", _m2["Coefficient"], 0.2268710, 0.00050)
_check("TFP SE", _m2["SE"], 0.0597696, 0.00050)

_cf = pd.read_csv(ROOT / "tables" / "aggregate_counterfactual.csv")
_post = _cf.loc[_cf["quarter_n"] >= POST_START_QUARTER_N]
_check("post observed mean", _post["wage_spread"].mean(), 0.4963, 0.00020)
_check("post counterfactual mean", _post["counterfactual"].mean(), 0.4719, 0.00030)

print("REPLICATION CHECKS PASSED")
