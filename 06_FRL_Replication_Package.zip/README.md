# Replication package

Does Exposure to Generative AI Widen Posted Wage Ranges? Evidence from China

## Run the analysis

Install Python 3.11 or later and the dependencies, then run:

```bash
python -m pip install -r requirements.txt
python replicate.py
```

The default command generates the preferred occupation-clustered estimates and
the original supplementary specifications, including 200 posting-level
permutations. It writes to `replication_output/` and checks the original
numerical benchmarks. The `--frl` flag runs just the revised specifications and
figures, `--legacy` runs the original supplementary specifications, and
`--smoke` checks the original baseline coefficient.

The regression-table statistics are written to
`replication_output/frl/FRL_model_statistics.csv`. To reproduce just the
regression-table statistics, use `python replicate.py --table-statistics all`.
The `main` and `appendix` selections split the calculation into two parts.
Use both for the complete set of models in the Online Appendix.

Adjusted R² uses the original outcome total sum of squares and the
fixed-effects model residual sum of squares. The absorbed rank subtracts, for
each successive fixed effect, the largest number of redundant parameters
identified by pairwise connected components. Adjusted R² is reported for
OLS columns. Coefficient tests use a two-sided t distribution with the
number of clusters minus one degree of freedom.

## Manuscript outputs

| Item | Output path under replication_output |
| --- | --- |
| Table 1 | tables/table_b1_summary.csv |
| Table 2 | frl/FRL_model_statistics.csv: range_quarter, range_city, range, upper, lower |
| Table 3 | frl/FRL_model_statistics.csv: quartiles, omit_2023q3, omit_2024q3, listed, first, reduced, iv |
| Table 4 | frl/FRL_model_statistics.csv: cog_*, phys_*, exp_* |
| Table 5 | frl/FRL_model_statistics.csv: hire_*, prod_tfp |
| Figure 1 | frl/FRL_event_study.png and frl/FRL_event_study.csv |
| Figure 2 | frl/FRL_counterfactual.png and frl/FRL_counterfactual.csv |
| Online appendix | frl/FRL_sample_flow.csv, frl/FRL_diagnostics.csv and supplementary tables under tables/ |

The data archive contains four prepared analysis tables. The raw Liepin data
are proprietary. The SHA-256 of the prepared archive is
`8aaa647181b373c6fb7dfa979fc48900b08aceea6845a2470d35e7fe2af2c91a`.
The original variable dictionary is in `README_legacy.md`.

`id_class2` identifies the 100 occupation classes in the preferred model.
`exposure` is constant within each class. `quarter_n` runs from 3 for 2022Q3
through 11 for 2024Q3. The prepared posting file uses `part_time.isna()` for
its full-time sample flag. `wage_spread` is the log winsorized upper wage
minus the log winsorized lower wage. The preferred design interacts exposure
with a post indicator starting in 2023Q3.

## Disclosure analysis

To estimate disclosure on a separate file containing all full-time job postings
including ads with incomplete or missing wage information, run:

```bash
python replicate.py --disclosure-input /path/to/unconditional_postings.csv
```

Supply one unique row per ad with fields `posting_id`, `id`, `id_class2`,
`city_id`, `industry4n`, `quarter_n`, `exposure`, and `has_wage_range`.
Use `has_wage_range=1` for an advertised range and 0 for missing or
incomplete disclosure. The command produces quarterly coverage tables
and the occupation-clustered linear probability model.
