"""Model-level statistics for the manuscript and appendix regression tables."""
from pathlib import Path
from itertools import combinations

import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.stats import t

POSTING_FE = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
FIRM_FE = ["id", "quarter_n"]
OCC = "id_class2"
IND = "industry4n"
EXPOSURE_POST = "treatmentq_ie"
WAGE_RANGE = "wage_spread"


def absorbed_rank(codes):
    """Pairwise connected-component approximation to the fixed-effect rank."""
    sizes = [int(c.max()) + 1 for c in codes]
    redundant = [0] * len(codes)
    for i, j in combinations(range(len(codes)), 2):
        offset = codes[j] + sizes[i]
        size = sizes[i] + sizes[j]
        graph = coo_matrix(
            (np.ones(len(offset), dtype=bool), (codes[i], offset)), shape=(size, size)
        ).tocsr()
        components = connected_components(graph, directed=False, return_labels=False)
        redundant[j] = max(redundant[j], components)
    return sum(sizes) - sum(redundant)


def adjusted_r2(y, residuals, n_parameters):
    n = len(y)
    outcome = np.asarray(y, dtype=np.float64)
    centered = outcome - outcome.mean()
    tss = centered @ centered
    if tss <= 0 or n <= n_parameters:
        return np.nan
    return 1 - (residuals @ residuals) / tss * (n - 1) / (n - n_parameters)


def run(data, fit, prepare, residualize, correction, one_x, root, segment=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    d = data["liepin_posting"]
    full = d.part_time.isna() & d.quarter_n.between(3, 11)
    listed = data["listed_posting"]
    listed_mask = listed.full_time.eq(1) & listed.quarter_n.between(3, 11)
    rows = {}
    columns = ["Estimate","SE","p","N","Clusters","Adjusted R2","First-stage F"]
    partial = root / f"partial_{segment or 'full'}.csv"
    partial.unlink(missing_ok=True)

    def record(key, b, se, y, residuals, rank, cluster, first_f=np.nan, ols=True):
        g = int(pd.Series(cluster).nunique())
        rows[key] = [b, se, 2*t.sf(abs(b/se), g-1), len(y), g,
                     adjusted_r2(y, residuals, rank) if ols else np.nan, first_f]
        if segment:
            pd.DataFrame([rows[key]],index=[key],columns=columns).to_csv(
                partial,mode="a",header=not partial.exists(),index_label="Model")

    def ols(key, frame=d, outcome=WAGE_RANGE, regs=(EXPOSURE_POST,),
            fes=POSTING_FE, cluster=IND, mask=full, repeat=20):
        res = fit(frame, outcome, list(regs), fes, cluster, mask, iterations=repeat)
        r, s = res["residualized"], res["sample"]
        error = r[:, 0] - r[:, 1:] @ res["beta"]
        b, se = res["beta"][0], res["se"][0]
        record(key, b, se, s[outcome], error, absorbed_rank(res["codes"]) + len(regs), s[cluster])
        return res

    def iv_reports():
        for gpt in (False, True):
            xs = [EXPOSURE_POST, "treatment_aioe2"] + (["treatmentq_gpt"] if gpt else [])
            s, codes = prepare(d, [WAGE_RANGE], xs, POSTING_FE, IND, full)
            r = residualize(s[[WAGE_RANGE, *xs]].to_numpy(), codes, 20)
            y, x, z = r[:, :3].T
            k = len(xs) - 1
            rank = absorbed_rank(codes) + k
            if gpt:
                w = r[:, 3]
                ww = w @ w
                y, x, z = [v - w * (w @ v / ww) for v in (y, x, z)]
            cl = s[IND].to_numpy()
            q = correction(codes, cl, k)
            codes_cl = pd.factorize(cl, sort=False)[0]

            def score_se(regressor, error, denom):
                score = np.bincount(codes_cl, weights=regressor*error)
                return np.sqrt(q * (score @ score))/abs(denom)

            zz = z @ z
            first = (z @ x)/zz
            first_error = x-first*z
            first_se = score_se(z, first_error, zz)
            first_f = (first/first_se)**2
            reduced = (z @ y)/zz
            rf_error = y-reduced*z
            xz = z @ x
            b = (z @ y)/xz
            error = y-b*x
            key = "iv_gpt" if gpt else "iv"
            record(key,b,score_se(z,error,xz),s[WAGE_RANGE],error,rank,cl,first_f,False)
            if not gpt:
                record("first",first,first_se,s[EXPOSURE_POST],first_error,rank,cl,first_f)
                record("reduced",reduced,score_se(z,rf_error,zz),s[WAGE_RANGE],rf_error,rank,cl)

    if segment in (None, "main"):
        ols("range_quarter",fes=["id",OCC,"quarter_n"],cluster=OCC)
        ols("range_city",fes=["id",OCC,("city_id","quarter_n")],cluster=OCC)
        base = ols("range",cluster=OCC,repeat=60)
        ols("upper",outcome="highest_salary",cluster=OCC,repeat=60)
        ols("lower",outcome="lowest_salary",cluster=OCC,repeat=60)
        scores = d[[OCC, "exposure"]].dropna().groupby(OCC).exposure.first()
        cut = scores.reindex(base["sample"][OCC].unique())
        low, high = cut.quantile([.25,.75])
        tails = d.exposure.le(low) | d.exposure.ge(high)
        quartile = d.assign(top_quartile_post=d.exposure.ge(high).astype(float)*d.post2)
        ols("quartiles",quartile,regs=("top_quartile_post",),cluster=OCC,mask=full & tails,repeat=60)
        ols("omit_2023q3",cluster=OCC,mask=full & d.quarter_n.ne(7),repeat=60)
        ols("omit_2024q3",cluster=OCC,mask=full & d.quarter_n.ne(11),repeat=60)
        ols("listed",listed,cluster=OCC,mask=listed_mask,repeat=60)
        iv_reports()
        for key,var,cluster,iterations in (
            ("cog_nonroutine","nonroutine_cognitive",OCC,60),("cog_routine","routine_cognitive",OCC,60),
            ("phys_nonroutine","nonroutine_physical",IND,20),("phys_routine","routine_physical",IND,20),
            ("exp_low","exp_5_below",IND,20),("exp_mid","exp_5_10",IND,20),("exp_high","exp_10_above",IND,20),
        ):
            ols(key,cluster=cluster,mask=full & d[var].eq(1),repeat=iterations)

        fd = data["liepin_firm_quarter"]
        qd = data["listed_firm_quarter"]
        for key,y in (
            ("hire_total","job_posting"),("hire_cog_r","log_routine_cog_postings"),
            ("hire_cog_nr","log_nonroutine_cog_postings"),("hire_phys_r","log_routine_phys_postings"),
            ("hire_phys_nr","log_nonroutine_phys_postings"),
        ):
            ols(key,fd,outcome=y,fes=FIRM_FE,mask=fd.quarter_n.between(3,11))
        for key,y in (("prod_tfp","TFP_OP"),("prod_manage","manage"),("prod_labor","labor"),
                      ("prod_rd","rd_int"),("prod_patent","patent")):
            ols(key,qd,outcome=y,fes=FIRM_FE,mask=qd.quarter_n.between(3,11))

    if segment in (None, "appendix", "endpoints"):
        ols("alt_range",repeat=60)
        ols("alt_upper",outcome="highest_salary",repeat=60)
        ols("alt_lower",outcome="lowest_salary",repeat=60)

    if segment in (None, "appendix"):
        ols("fe1",fes=["id",OCC,"quarter_n"])
        ols("fe2",fes=["id",OCC,("city_id","quarter_n")])
        ols("alt_listed",listed,mask=listed_mask)
        for key,x in (("median","treatment_high"),("gpt","exposure_gpt_dwa"),
                      ("claude","exposure_claude_dwa"),("gpt_future","exposure_gpt_future"),
                      ("claude_future","exposure_claude_fu")):
            ols(key,regs=(x,))
        extra = ["industry_1n","industry_2n","industry_3n"]
        common = fit(d,WAGE_RANGE,[EXPOSURE_POST],POSTING_FE,IND,full,extra_cols=extra)
        cr, cs = common["residualized"], common["sample"]
        rank = absorbed_rank(common["codes"])+1
        for key,c in (("one","industry_1n"),("two","industry_2n"),("three","industry_3n"),
                      ("occupation",OCC),("firm","id")):
            b,se = one_x(cr,cs[c],common["codes"])
            record(key,b,se,cs[WAGE_RANGE],cr[:,0]-b*cr[:,1],rank,cs[c])
        for key,var in (("traditional","traditional_ai_exposure"),("pandemic","covid_exposure")):
            controls = {f"{var}_{q}": np.where(d.quarter_n.eq(q),d[var],0.0) for q in range(3,12)}
            ols(key,d.assign(**controls),regs=(EXPOSURE_POST,*controls))
        ols("expanded",mask=d.quarter_n.between(3,11) & (d.part_time.isna() | d.gig_work.isna()))
        ols("since2023",mask=full & d.quarter_n.ge(5))
        for key,var in (("alt_cog_r","routine_cognitive"),("alt_cog_nr","nonroutine_cognitive"),
                        ("alt_phys_r","routine_physical"),("alt_phys_nr","nonroutine_physical"),
                        ("alt_exp_low","exp_5_below"),("alt_exp_mid","exp_5_10"),("alt_exp_high","exp_10_above")):
            ols(key,mask=full & d[var].eq(1))
        for key,var,val in (("tier1","city_rank",1),("tier_other","city_rank",0),
                            ("master","masters_phd",1),("lower_edu","masters_phd",0)):
            ols(key,mask=full & d[var].eq(val))
        for n in range(4):
            subset=d.total_skills4.eq(n) if n<3 else d.total_skills4.ge(3)
            ols(f"soft_{n}",mask=full & subset)

    partial.unlink(missing_ok=True)
    pd.DataFrame.from_dict(rows,orient="index",columns=columns).to_csv(
        root / (f"FRL_models_{segment}.csv" if segment else "FRL_model_statistics.csv"),index_label="Model")
