"""Estimate wage-range disclosure on an unconditional file supplied separately."""
import numpy as np
import pandas as pd
from scipy.stats import t

COLUMNS = ["posting_id", "id", "id_class2", "city_id", "industry4n",
           "quarter_n", "exposure", "has_wage_range"]


def run(path, fit, root):
    d = pd.read_csv(path, usecols=COLUMNS, dtype={"posting_id": "string"})
    if d.posting_id.isna().any() or d.posting_id.duplicated().any():
        raise ValueError("Each observation must have a unique, nonmissing posting ID.")
    if not d.quarter_n.between(3, 11).all():
        raise ValueError("Supply full-time postings in quarters 3–11 of the study window.")
    if not d.has_wage_range.isin([0, 1]).all() or d.has_wage_range.nunique() != 2:
        raise ValueError("Supply an unconditional file with both range and nonrange postings and a binary flag.")

    eligible = d.dropna(subset=["id_class2", "exposure", "id", "city_id", "industry4n"]).copy()
    scores = eligible.groupby("id_class2").exposure
    if not scores.nunique().eq(1).all():
        raise ValueError("Each occupation class must have one time-invariant score.")
    low, high = scores.first().quantile([.25, .75])
    eligible["exposure_group"] = np.select(
        [eligible.exposure.le(low), eligible.exposure.ge(high)],
        ["Bottom quartile", "Top quartile"],
        default="Middle half",
    )
    root.mkdir(parents=True, exist_ok=True)
    for name, frame, keys in [
        ("all", d, ["quarter_n"]),
        ("class", eligible, ["quarter_n", "id_class2"]),
        ("exposure_group", eligible, ["quarter_n", "exposure_group"]),
    ]:
        counts = frame.groupby(keys).has_wage_range.agg(
            ads="size", ads_with_range="sum", disclosure_rate="mean")
        counts.to_csv(root/f"disclosure_by_{name}.csv")
    eligible["exposure_post"] = eligible.exposure * eligible.quarter_n.ge(7)
    fes = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
    fit_result = fit(eligible, "has_wage_range", ["exposure_post"], fes,
                     "id_class2", pd.Series(True, index=eligible.index), iterations=60)
    clusters = fit_result["sample"].id_class2.nunique()
    b, se = fit_result["beta"][0], fit_result["se"][0]
    pd.DataFrame([{"Coefficient": b, "SE": se, "N": fit_result["N"],
                   "Clusters": clusters, "p": 2*t.sf(abs(b/se), clusters-1)}]
                 ).to_csv(root/"disclosure_regression.csv", index=False)
