"""Generate sample counts and a sensitivity to the last sample quarter."""
import pandas as pd
from scipy.stats import t


def run(d, listed, fit, prepare, root):
    root.mkdir(parents=True, exist_ok=True)
    index = "id_class2"
    fes = ["id", index, ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
    data_mask = d.quarter_n.between(3, 11)
    full = data_mask & d.part_time.isna()
    y, x = "wage_spread", "treatmentq_ie"
    group, _ = prepare(d, [y], [x], fes, index, full, ["exposure"])
    keys = pd.Index(range(3, 12), name="Quarter")
    flow = pd.DataFrame({
        "Prepared": d.loc[data_mask].groupby("quarter_n").size().reindex(keys),
        "Full-time": d.loc[full].groupby("quarter_n").size().reindex(keys),
        "Estimation": group.groupby("quarter_n").size().reindex(keys),
        "Occupation classes": group.groupby("quarter_n")[index].nunique().reindex(keys)
    })
    flow.index = [f"{2022+(n-1)//4}Q{(n-1)%4+1}" for n in keys]
    flow.to_csv(root/"FRL_sample_flow.csv", index_label="Quarter")
    records = []
    for label, df, mask in [
        ("Excluding 2024Q3", d, full & d.quarter_n.ne(11)),
        ("Listed-firm postings", listed, listed.full_time.eq(1) & listed.quarter_n.between(3, 11)),
    ]:
        res = fit(df, y, [x], fes, index, mask, iterations=60)
        b,s = res["beta"][0],res["se"][0]
        g = res["sample"][index].nunique()
        records.append([label,b,s,res["N"],g,2*t.sf(abs(b/s),g-1)])
    pd.DataFrame(records,columns=["Specification","Coefficient","SE","N","Clusters","p"]).to_csv(root/"FRL_supplement.csv",index=False)
