"""Reproduce the wage-range results reported in the FRL manuscript."""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t, f
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def run(data, fit, root):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    d = data.copy()
    base = d.part_time.isna() & d.quarter_n.between(3, 11)
    fes = ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")]
    cluster = "id_class2"
    x = ["treatmentq_ie"]
    rows = []

    def result(label, outcome, regressors, mask):
        r = fit(d, outcome, regressors, fes, cluster, mask, iterations=60,
                extra_cols=["exposure", "industry4n"])
        g = r["sample"][cluster].nunique()
        b, s = r["beta"][0], r["se"][0]
        rows.append([label, b, s, r["N"], g, 2*t.sf(abs(b/s), g-1)])
        return r

    r = result("Log wage range", "wage_spread", x, base)
    result("Log lower wage", "lowest_salary", x, base)
    result("Log upper wage", "highest_salary", x, base)
    result("Omit 2023Q3", "wage_spread", x, base & d.quarter_n.ne(7))
    result("Non-routine cognitive", "wage_spread", x, base & d.nonroutine_cognitive.eq(1))
    result("Routine cognitive", "wage_spread", x, base & d.routine_cognitive.eq(1))
    by_occ = r["sample"].groupby(cluster).exposure
    if not by_occ.nunique().eq(1).all():
        raise ValueError("Exposure must be constant within each occupation class")
    q1, q3 = by_occ.first().quantile([.25, .75])
    lo, hi = d.exposure.le(q1), d.exposure.ge(q3)
    d["top_quartile_post"] = hi.astype(float)*d.post2
    binary = result("Top vs bottom exposure quartiles", "wage_spread",
                    ["top_quartile_post"], base & (lo | hi))
    pd.DataFrame(rows, columns=["Specification", "Coefficient", "SE", "N", "Clusters", "p"]).to_csv(root/"FRL_table_1.csv", index=False)
    ev_x = ["t2pre4", "t2pre3", "t2pre2", "t2current", "t2post1", "t2post2", "t2post3", "t2post4"]
    e = fit(d, "wage_spread", ev_x, fes, cluster, base, iterations=60)
    g = e["sample"][cluster].nunique()
    pre_b = e["beta"][:3]
    pre_v = e["vcov"][:3, :3]
    joint = float(pre_b @ np.linalg.solve(pre_v, pre_b))/3
    ev = pd.DataFrame({"Quarter": ["2022Q3","2022Q4","2023Q1","2023Q3","2023Q4","2024Q1","2024Q2","2024Q3"], "Coefficient": e["beta"], "SE": e["se"]})
    ev = pd.concat([ev.iloc[:3],pd.DataFrame({"Quarter":["2023Q2"],"Coefficient":[0.],"SE":[0.]}),ev.iloc[3:]],ignore_index=True)
    ev.to_csv(root/"FRL_event_study.csv",index=False)
    fig, ax = plt.subplots(figsize=(7.2,3.1), layout="constrained")
    pos=np.arange(len(ev))
    ax.axvspan(3.5,8.5,color="#edf4f3")
    ax.axhline(0,color="#777777",lw=.8)
    ax.axvline(3.5,color="#777777",lw=.8,ls="--")
    ax.errorbar(pos,ev.Coefficient,yerr=t.ppf(.975,g-1)*ev.SE,fmt="o",color="#194a51",ms=4,capsize=3,lw=1.2)
    ax.set(xticks=pos,xticklabels=ev.Quarter,ylabel="Exposure × quarter coefficient",xlim=(-.4,8.4))
    ax.tick_params(axis="x",labelsize=8)
    ax.spines[["top","right"]].set_visible(False)
    fig.savefig(root/"FRL_event_study.png",dpi=320)
    plt.close(fig)
    p10,p90=r["sample"].exposure.quantile([.1,.9])
    metrics = dict(pretrend_F=joint,pretrend_p=f.sf(joint,3,g-1),
        p10=p10,p90=p90,mean_spread=r["sample"].wage_spread.mean(),
        sd_spread=r["sample"].wage_spread.std(),q1=q1,q3=q3,
        bottom_classes=by_occ.first().le(q1).sum(),top_classes=by_occ.first().ge(q3).sum(),
        all_prepared_postings=len(d),observed_both_bounds=d[["lowest_salary","highest_salary"]].notna().all(axis=1).sum())
    pd.Series(metrics).to_csv(root/"FRL_diagnostics.csv",header=["value"])
