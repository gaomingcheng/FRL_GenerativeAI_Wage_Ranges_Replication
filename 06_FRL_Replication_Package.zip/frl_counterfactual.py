"""Construct the quarterly exposure-adjusted wage-range series."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def run(d, prepare, root):
    exposure = pd.read_csv(root / "FRL_table_1.csv").iloc[0]["Coefficient"]
    sample, _ = prepare(
        d, ["wage_spread"], ["treatmentq_ie"],
        ["id", "id_class2", ("city_id", "quarter_n"), ("industry4n", "quarter_n")],
        "id_class2", d.part_time.isna() & d.quarter_n.between(3, 11))
    sample["exposure_adjusted"] = sample.wage_spread - exposure * sample.treatmentq_ie
    q = sample.groupby("quarter_n")[["wage_spread", "exposure_adjusted"]].mean()
    q.index = [f"{2022+(n-1)//4}Q{(n-1)%4+1}" for n in q.index.astype(int)]
    q.index.name = "Quarter"
    q.to_csv(root / "FRL_counterfactual.csv")

    fig, ax = plt.subplots(figsize=(7.2, 3.1), layout="constrained")
    ax.axvspan(3.5, 8.5, color="#edf4f3")
    ax.axvline(3.5, color="#777777", lw=.8, ls="--")
    ax.plot(q.index, q.wage_spread, label="Observed", color="#194a51", marker="o", ms=3.5)
    ax.plot(q.index, q.exposure_adjusted, label="Exposure-adjusted", color="#a75939", marker="s", ms=3.2, lw=1.3)
    ax.set(ylabel="Mean posted log wage range", xlim=(-.4, 8.4))
    ax.tick_params(axis="x", labelsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(loc="lower left", frameon=False, fontsize=8)
    fig.savefig(root / "FRL_counterfactual.png", dpi=320)
    plt.close(fig)
