# Replication Package

## Article
Generative AI exposure and within-vacancy wage ranges: evidence from China

## Files
The replication archive contains exactly three source files:

1. `replication_data.pkl.gz` - one compressed analysis-data object.
2. `replicate.py` - the complete replication code.
3. `README.md` - this documentation and variable dictionary.

The archive contains only the three source files listed above; all tables and figures are generated when the code is run.

## Data
`replication_data.pkl.gz` is a gzip-compressed Python pickle containing four pandas DataFrames:

- `liepin_posting`: posting-level Liepin analysis data.
- `listed_posting`: listed-firm posting data.
- `liepin_firm_quarter`: firm-quarter Liepin outcomes.
- `listed_firm_quarter`: listed-firm quarterly outcomes.

The raw Liepin data are proprietary and cannot be redistributed. The included analysis-ready data are sufficient to reproduce the reported results.

SHA-256: `8aaa647181b373c6fb7dfa979fc48900b08aceea6845a2470d35e7fe2af2c91a`

## Software
Recommended environment:

- Python 3.11 or later
- numpy 1.26 or later
- pandas 2.0 or later
- matplotlib 3.7 or later
- Pillow 10.0 or later

Install the required packages with:

```bash
python -m pip install numpy pandas matplotlib Pillow
```

## Running the replication
From the package directory, run:

```bash
python replicate.py
```

The script recreates all reported summary statistics, baseline estimates, endpoint regressions, event-study estimates, robustness checks, instrumental-variable estimates, auxiliary outcomes, heterogeneity estimates, the permutation placebo exercise, the aggregate counterfactual, and the figures.

Generated results are written to a newly created `replication_output/` directory. Generated outputs are deliberately excluded from the submitted archive because they are products of the reproduction code rather than source inputs.

For a quick numerical check of the preferred baseline result, run:

```bash
python replicate.py --smoke
```

The default full replication uses 200 placebo permutations. A diagnostic run can override that number, for example:

```bash
python replicate.py --placebo-reps 20
```

## Preferred specification
The analysis window is 2022Q3-2024Q3 and the post period begins in 2023Q3. The preferred posting-level model absorbs occupation-class fixed effects, firm fixed effects, city-by-quarter fixed effects, and four-digit-industry-by-quarter fixed effects. Standard errors are clustered by four-digit industry.

The event study omits 2023Q2. The aggregate counterfactual is constructed on the preferred estimation sample as:

`counterfactual wage range = observed wage range - beta x exposure x post`

## Numerical verification
The script checks the headline results against manuscript-level benchmarks and stops with an error if any checked result is outside its numerical tolerance. Checked quantities include:

- preferred wage-range coefficient and clustered standard error;
- preferred sample size;
- upper- and lower-wage endpoint coefficients and standard errors;
- instrumental-variable coefficient, standard error, and Kleibergen-Paap F statistic;
- firm-quarter total-posting coefficient and standard error;
- listed-firm TFP coefficient and standard error;
- post-period observed and counterfactual mean wage ranges.

After iterative singleton removal, fixed-effect codes are re-factorised before absorbed degrees of freedom are calculated. This ensures that empty category labels are not counted in the finite-sample cluster correction.

## Variable dictionary

| Variable | Dataset | Definition | Source |
|---|---|---|---|
| id | All datasets | Firm identifier | Prepared data |
| year | liepin_posting | Calendar year | Constructed |
| quarter_n | All datasets | Quarter index: 3=2022Q3 through 11=2024Q3 | Constructed |
| salary | Posting datasets | Log average monthly posted wage | Liepin |
| average_wage_level | liepin_posting | Winsorised average monthly wage in levels | Liepin |
| highest_salary | liepin_posting | Log winsorised upper monthly wage bound | Liepin |
| lowest_salary | liepin_posting | Log winsorised lower monthly wage bound | Liepin |
| wage_spread | Posting datasets | Log upper wage minus log lower wage | Constructed |
| exposure | liepin_posting | Occupation-level GenAI exposure index | Task-based occupation exposure series |
| post2 | liepin_posting | Indicator equal to one from 2023Q3 | Constructed |
| treatmentq_ie | All datasets | Post indicator multiplied by occupation-level GenAI exposure | Constructed |
| id_class2 | Posting datasets | Occupation-class identifier | Prepared data |
| city_id | Posting datasets | City identifier | Prepared data |
| city_rank | liepin_posting | Tier-1 city indicator | Constructed |
| industry4n | All datasets | Four-digit industry identifier | Prepared firm data |
| industry_1n | liepin_posting | One-digit industry identifier | Prepared firm data |
| industry_2n | liepin_posting | Two-digit industry identifier | Prepared firm data |
| industry_3n | liepin_posting | Three-digit industry identifier | Prepared firm data |
| t2pre6 | liepin_posting | Quarter-specific exposure interaction | Constructed |
| t2pre5 | liepin_posting | Quarter-specific exposure interaction | Constructed |
| t2pre4 | liepin_posting | Exposure interaction for 2022Q3 | Constructed |
| t2pre3 | liepin_posting | Exposure interaction for 2022Q4 | Constructed |
| t2pre2 | liepin_posting | Exposure interaction for 2023Q1 | Constructed |
| t2current | liepin_posting | Exposure interaction for 2023Q3 | Constructed |
| t2post1 | liepin_posting | Exposure interaction for 2023Q4 | Constructed |
| t2post2 | liepin_posting | Exposure interaction for 2024Q1 | Constructed |
| t2post3 | liepin_posting | Exposure interaction for 2024Q2 | Constructed |
| t2post4 | liepin_posting | Exposure interaction for 2024Q3 | Constructed |
| treatment_high | liepin_posting | Post indicator multiplied by above-median exposure indicator | Constructed |
| exposure_gpt_dwa | liepin_posting | Alternative GPT-4-based exposure interacted with post | Constructed |
| exposure_claude_dwa | liepin_posting | Alternative Claude-4-based exposure interacted with post | Constructed |
| exposure_gpt_future | liepin_posting | Alternative future GPT-based exposure interacted with post | Constructed |
| exposure_claude_fu | liepin_posting | Alternative future Claude-based exposure interacted with post | Constructed |
| treatment_aioe2 | liepin_posting | US occupational AI exposure instrument interacted with post | Felten, Raj, and Seamans (2021) |
| treatmentq_gpt | liepin_posting | Additional GPT exposure control interacted with post | Constructed |
| traditional_ai_exposure | liepin_posting | Traditional-AI occupational exposure | Prepared research variable |
| covid_exposure | liepin_posting | Occupation-level pandemic exposure control | Prepared research variable |
| part_time | liepin_posting | Part-time indicator; missing identifies full-time observations | Liepin |
| gig_work | liepin_posting | Gig-work indicator | Constructed |
| masters_phd | liepin_posting | Indicator for master/PhD requirement | Constructed |
| total_skills4 | liepin_posting | Count of soft-skill requirements | Constructed |
| exp_5_below | liepin_posting | Indicator for experience requirement of five years or less | Constructed |
| exp_5_10 | liepin_posting | Indicator for experience requirement of five to ten years | Constructed |
| exp_10_above | liepin_posting | Indicator for experience requirement above ten years | Constructed |
| routine_cognitive | Posting and firm datasets | Routine cognitive task indicator | Prepared classification |
| nonroutine_cognitive | Posting and firm datasets | Non-routine cognitive task indicator | Prepared classification |
| routine_physical | Posting and firm datasets | Routine physical task indicator | Prepared classification |
| nonroutine_physical | Posting and firm datasets | Non-routine physical task indicator | Prepared classification |
| log_routine_cog_postings | liepin_firm_quarter | Log firm-quarter routine cognitive posting count | Constructed |
| log_nonroutine_cog_postings | liepin_firm_quarter | Log firm-quarter non-routine cognitive posting count | Constructed |
| log_routine_phys_postings | liepin_firm_quarter | Log firm-quarter routine physical posting count | Constructed |
| log_nonroutine_phys_postings | liepin_firm_quarter | Log firm-quarter non-routine physical posting count | Constructed |
| job_posting | liepin_firm_quarter | Log firm-quarter total postings | Constructed |
| full_time | listed_posting | Full-time indicator | Prepared listed-firm posting data |
| lower_wage_level | listed_posting | Winsorised lower monthly wage bound in levels | Prepared data |
| upper_wage_level | listed_posting | Winsorised upper monthly wage bound in levels | Prepared data |
| rd_int | listed_firm_quarter | R&D intensity | Listed-firm reports |
| patent | listed_firm_quarter | Log invention patent count | Listed-firm reports |
| manage | listed_firm_quarter | Log management efficiency | Listed-firm reports |
| labor | listed_firm_quarter | Log labour productivity | Listed-firm reports |
| TFP_OP | listed_firm_quarter | Olley-Pakes total factor productivity estimate | Listed-firm reports |

## Output map
A complete run creates:

- `replication_output/tables/table_b1_summary.csv` through `table_b3_summary.csv`: descriptive statistics;
- `replication_output/tables/table_c1_baseline.csv`: baseline specifications and wage endpoints;
- `replication_output/tables/table_event_study.csv`: event-study estimates;
- `replication_output/tables/table_r1_listed_sample.csv` through `table_r5_iv.csv`: robustness and IV results;
- `replication_output/tables/table_m1_displacement.csv` and `table_m2_productivity.csv`: auxiliary outcomes;
- `replication_output/tables/table_h1_occupation.csv` through `table_h5_experience.csv`: heterogeneity;
- `replication_output/tables/placebo_coefficients.csv`: placebo coefficients;
- `replication_output/tables/aggregate_counterfactual.csv`: observed and counterfactual quarterly means;
- `replication_output/figures/fig1_event_study.png`, `fig2_placebo.png`, `fig3_counterfactual.png`, and `Figure1_main_submission.png`.

## Data handling
Firm identifiers in the prepared data are analysis identifiers. The package does not include names, contact information, free-text vacancy descriptions, or raw web-scrape files.
